This package has the same content as rdf2oaiRDB.zip, with the following changes:

rdf2oaiSDB.jar
 - replaces rdf2oai.jar
 - from http://ands-vitro-code.googlecode.com/files/rdf2oaiSDB.jar
 - date: May 19 2011
 - SHA1: d2259010b70447e1b3cece8afc2297f0d0cda7af